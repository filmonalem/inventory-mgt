export const stripeConfig = {
  secretKey: process.env.STRIPE_SECRET_KEY,
};
