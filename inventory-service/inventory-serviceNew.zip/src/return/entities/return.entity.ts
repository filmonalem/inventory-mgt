import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

class ReturnItem {
  @Column()
  productId: string;

  @Column('int')
  quantity: number;
}

@Entity()
export class Return {
  @PrimaryGeneratedColumn('uuid')
  returnId: string;

  @Column()
  clientId: string;

  @Column('jsonb')
  products: ReturnItem[]; // Stored as JSONB in PostgreSQL

  @Column()
  status: string;

  @Column()
  reason: string;
}
