import { Product } from 'src/product/entities/product.entity';
import { Entity, Column, PrimaryGeneratedColumn, OneToMany } from 'typeorm';

@Entity()
export class Order {
  @PrimaryGeneratedColumn('uuid')
  orderId: string;

  @Column()
  clientId: string;

  @Column()
  status: string;

  @OneToMany(() => Product, (product) => product.order)
  products: Product[];
}
