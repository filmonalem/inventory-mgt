import { CommonEntity } from 'src/common/common.entity';
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('stocks')
export class Stock extends CommonEntity {
  @PrimaryGeneratedColumn('uuid')
  stockId: string;

  @Column({ type: 'float' })
  totalPrice: number;

  @Column()
  expireDate: Date;
}
