import { Module } from '@nestjs/common';
import { ReturnController } from './return.controller';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { rabbitmqConfig } from 'src/Rabbitmq/rabbitmq.config.';

@Module({
  imports: [
    ClientsModule.register([
      {
        name: 'RETURN_SERVICE',
        transport: Transport.RMQ,
        options: rabbitmqConfig.options,
      },
    ]),
  ],
  controllers: [ReturnController],
})
export class ReturnModule {}
