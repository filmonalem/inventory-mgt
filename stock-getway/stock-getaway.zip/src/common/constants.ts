export const jwtConstants = {
  secret: 'complex',
};
