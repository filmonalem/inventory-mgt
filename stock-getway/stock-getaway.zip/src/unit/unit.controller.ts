import { Body, Controller, Get, Inject, Post, Query } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { Observable } from 'rxjs';

@Controller('unit')
export class UnitController {
  constructor(@Inject('COMPANY_SERVICE') private unitProxy: ClientProxy) {}
  @Post()
  createUnit(@Body() data: any): Observable<any> {
    return this.unitProxy.emit('createUnit', data);
  }
  @Get()
  getAllUnit() {
    return this.unitProxy.send('getAllUnit', {});
  }

  @Get('search')
  searchUnits(@Query() query: string) {
    return this.unitProxy.emit('searchUnit', query);
  }
}
