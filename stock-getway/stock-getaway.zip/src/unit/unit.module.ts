import { Module } from '@nestjs/common';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { UnitController } from './unit.controller';
import { rabbitmqConfig } from 'src/Rabbitmq/rabbitmq.config.';

@Module({
  imports: [
    ClientsModule.register([
      {
        name: 'COMPANY_SERVICE',
        transport: Transport.RMQ,
        options: rabbitmqConfig.options,
      },
    ]),
  ],
  controllers: [UnitController],
})
export class UnitModule {}
