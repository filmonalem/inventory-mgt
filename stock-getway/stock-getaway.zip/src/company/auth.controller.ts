// import { Controller, Get, Inject, Post, Put } from '@nestjs/common';
// import { ClientProxy, Payload } from '@nestjs/microservices';
// import { Observable } from 'rxjs';

// @Controller('auth')
// export class AuthController {
//   constructor(
//     @Inject('COMPANY_SERVICE') private readonly authProxy: ClientProxy,
//   ) {}

//   @Post('signup')
//   signup(@Payload() data: any): Observable<any> {
//     return this.authProxy.emit('signup', data);
//   }

//   @Post('login')
//   login(@Payload() data: any): Observable<any> {
//     return this.authProxy.emit('login', data);
//   }

//   @Post('logout')
//   logout(): Observable<any> {
//     return this.authProxy.emit('logout', {});
//   }

//   @Get()
//   findAllUser() {
//     return this.authProxy.send({ cmd: 'getAllUser' }, {});
//   }

//   @Post('forgetPassword')
//   forgetPassword(@Payload() data: any): Observable<any> {
//     return this.authProxy.emit('forgetPassword', data);
//   }

//   @Post('changePassword/:id')
//   changePassword(@Payload() data: any): Observable<any> {
//     return this.authProxy.emit('changePassword', data);
//   }

//   @Put('status/:id')
//   suspendUser(@Payload() id: string) {
//     return this.authProxy.send({ cmd: 'suspendUser' }, id);
//   }
// }
